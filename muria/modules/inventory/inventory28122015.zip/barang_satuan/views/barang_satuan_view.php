<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Form Barang_satuan</h5>
                        
                    </div>
                    <div class="ibox-content">
                    <?php $this->load->view('barang_satuan_table') ?>


                    </div>
                </div>
                </div>
               
            </div>
          
            
</div>

