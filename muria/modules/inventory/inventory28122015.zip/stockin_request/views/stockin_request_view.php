<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Form Stockin_request</h5>
                        
                    </div>
                    <div class="ibox-content">
                    <?php $this->load->view('stockin_request_table') ?>


                    </div>
                </div>
                </div>
               
            </div>
          
            
</div>

