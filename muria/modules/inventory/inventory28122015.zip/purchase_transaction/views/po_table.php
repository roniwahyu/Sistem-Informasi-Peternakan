
<table id="datax" class="tabelpo table table-bordered table-condensed table-striped" style="">
    <thead class="">
    	<tr>
                                                       
                                                       <th style="width:70px">#Faktur PO</th>
                                                        <th>Tanggal</th>
                                                        <!-- <th>Kode</th> -->
                                                        <th>Nama Supplier</th>
                                                        <!-- <th>Tanggal Kirim</th> -->
                                                        <th>Total</th>
                                                        <th>Status</th>
                                                        <th>Cara Bayar</th>
                                                        <th style="width:100px">Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="7" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>