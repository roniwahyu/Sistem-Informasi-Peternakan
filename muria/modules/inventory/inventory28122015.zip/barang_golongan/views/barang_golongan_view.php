<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Form Barang_golongan</h5>
                        
                    </div>
                    <div class="ibox-content">
                    <?php $this->load->view('barang_golongan_table') ?>


                    </div>
                </div>
                </div>
               
            </div>
          
            
</div>

