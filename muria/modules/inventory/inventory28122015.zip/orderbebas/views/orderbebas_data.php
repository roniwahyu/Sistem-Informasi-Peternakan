<div class="datatable-ajax-source">
                                <table id="datatables" class="table table-bordered table-condensed table-striped" style="">
                                    <thead class="">
                                        <tr>
                                                       
                                                        <th>Tgl</th>
                                                        <th>Kepada</th>
                                                        <th>Alamat</th>
                                                        <th>Sopir</th>
                                                        <th>Mobil</th>
                                                        <th>Barang</th>
                                                        <th>User</th>
                                                        <th>Time</th>
                                                        <th>Status</th>
                                                        <th>cNoJrn</th>
                                                        <th>lVoid</th>
                                                        <th>lPosted</th>
                                                        <th>Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="13" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>