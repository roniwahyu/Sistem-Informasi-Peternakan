<div class="datatable-ajax-source">
        <h2 class="text-center">Tabel Data gudang</h2>
        <hr>
    <?php echo "<a data-toggle='modal' href='#modal-id' data-load-remote='".base_url('gudang/forms/')."' data-remote-target='#modal-id .modal-body' class='btn btn-primary'><i class='fa fa-plus'></i> Buka gudang Baru</a>";?>
    <div class="modal fade" id="modal-id">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Modal title</h4>
                </div>
                <div class="modal-body">
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
                                <table id="datatables" class="table table-bordered table-condensed table-striped" style="">
                                    <thead class="">
                                        <tr>
                                                       
                                                        <th>kd_gudang</th>
                                                        <th>nama</th>
                                                        <th>id_mitra</th>
                                                        <th>id_user</th>
                                                        <th>id_wilayah</th>
                                                        <th>status</th>
                                                        <th>datetime</th>
                                                        <th>timestamp</th>
                                                        <th>Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="9" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>