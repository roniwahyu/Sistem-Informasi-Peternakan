<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<?php echo !empty($content)?$content:''; ?>		
		</div>	
	</div>
</div>	