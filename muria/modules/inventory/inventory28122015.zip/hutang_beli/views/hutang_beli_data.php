<div class="datatable-ajax-source">
                                <table id="datatables" class="table table-bordered table-condensed table-striped" style="">
                                    <thead class="">
                                        <tr>
                                                       
                                                        <th class="text-center" style="width:10%">Kode</th>
                                                        <th class="text-center" style="width:60%">Nama</th>
                                                        <th class="text-center" style="width:10%">Hutang</th>
                                                        <th class="text-center" style="width:10%">Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="4" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>