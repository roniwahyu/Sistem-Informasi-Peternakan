<div class="datatable-ajax-source">
        <hr>
        <h2 class="text-center">Tabel Data barang_harga</h2>
    <div class="modal fade" id="modal-id">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Detail barang_harga</h4>
                </div>
                <div class="modal-body">
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
                                <table id="datatables" class="table table-bordered table-condensed table-striped" style="">
                                    <thead class="">
                                        <tr>
                                                       
                                                        <th>id_barang</th>
                                                        <th>markup</th>
                                                        <th>hb1</th>
                                                        <th>hb2</th>
                                                        <th>hb3</th>
                                                        <th>hj1r</th>
                                                        <th>hj2r</th>
                                                        <th>hj3r</th>
                                                        <th>hj1u</th>
                                                        <th>hj2u</th>
                                                        <th>hj3u</th>
                                                        <th>hj2p</th>
                                                        <th>hj3p</th>
                                                        <th>hn1</th>
                                                        <th>hn2</th>
                                                        <th>hn3</th>
                                                        <th>max</th>
                                                        <th>datetime</th>
                                                        <th>Aksi</th>

                                                    </tr>
                                    </thead>

                                    <tbody class="table-bordered">
                                        <tr>
                                            <td colspan="19" class="text-center dataTables_empty"><img src="<?php echo assets_url('images/loader.gif');  ?>" title="Loading" alt="Loading">&nbsp;&nbsp; Loading data, please wait....</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>